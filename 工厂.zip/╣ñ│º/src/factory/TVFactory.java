package factory;
import tv.TV;
public interface TVFactory{
	public TV produceTV();
}