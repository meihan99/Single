package tv;
public class HaierTV implements TV{
	public void play(){
		System.out.println("This is a HaierTV");
	}
}