package tv;
public class HaisenTV implements TV{
	public void play(){
		System.out.println("This is a HaisenTV");
	}
}