package production;

import user.*;
public class AAUserProduce extends Produce{
	public User produceUser(){
		return new AAUser("15515158296");
	}
}
